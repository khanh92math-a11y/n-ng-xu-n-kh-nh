
import { GoogleGenAI, Type } from "@google/genai";
import { Question } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });

export const generateMathQuestions = async (): Promise<Question[]> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Tạo 15 câu hỏi trắc nghiệm về chủ đề "tính đơn điệu của hàm số" cho chương trình toán lớp 12 của Việt Nam. Các câu hỏi cần có độ khó tăng dần từ câu 1 (rất dễ) đến câu 15 (rất khó). Mỗi câu hỏi bao gồm: câu hỏi, 4 đáp án (A, B, C, D), và chỉ số của đáp án đúng (0 cho A, 1 cho B, 2 cho C, 3 cho D). Vui lòng định dạng đầu ra dưới dạng một mảng JSON. Mỗi đối tượng trong mảng phải có các khóa sau: "question", "answers" (một mảng 4 chuỗi), và "correctAnswerIndex" (một số). Tuyệt đối không thêm bất kỳ văn bản nào khác ngoài mảng JSON.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              answers: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              correctAnswerIndex: { type: Type.INTEGER },
            },
            required: ["question", "answers", "correctAnswerIndex"],
          },
        },
      },
    });

    const jsonText = response.text.trim();
    const questions = JSON.parse(jsonText);

    if (!Array.isArray(questions) || questions.length === 0) {
        throw new Error("Generated content is not a valid question array.");
    }
    
    // Validate that we have exactly 15 questions
    if (questions.length !== 15) {
        console.warn(`Gemini generated ${questions.length} questions, expected 15. Retrying...`);
        // You could add retry logic here, for now we throw an error
        throw new Error("Did not generate exactly 15 questions.");
    }

    return questions;
  } catch (error) {
    console.error("Error generating questions:", error);
    // In case of an error, return a mock question set or re-throw
    throw new Error("Failed to fetch questions from Gemini API.");
  }
};
