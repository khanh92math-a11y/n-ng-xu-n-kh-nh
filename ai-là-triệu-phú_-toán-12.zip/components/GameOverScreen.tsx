
import React from 'react';
import { PRIZE_AMOUNTS, TOTAL_QUESTIONS } from '../constants';

interface GameOverScreenProps {
  onPlayAgain: () => void;
  questionIndex: number; // 0-14
}

const GameOverScreen: React.FC<GameOverScreenProps> = ({ onPlayAgain, questionIndex }) => {
  
  let prizeWon = "0 VNĐ";
  if (questionIndex >= 10) {
    prizeWon = PRIZE_AMOUNTS[TOTAL_QUESTIONS - 10]; // Milestone at question 10
  } else if (questionIndex >= 5) {
    prizeWon = PRIZE_AMOUNTS[TOTAL_QUESTIONS - 5]; // Milestone at question 5
  }

  return (
    <div className="text-center flex flex-col items-center justify-center h-full">
      <h1 className="text-5xl font-bold mb-4 text-red-500">TRÒ CHƠI KẾT THÚC</h1>
      <p className="text-2xl text-cyan-300 mb-8">
        Bạn ra về với giải thưởng: <span className="font-bold text-yellow-300">{prizeWon}</span>
      </p>
      <button
        onClick={onPlayAgain}
        className="px-12 py-4 bg-gradient-to-b from-cyan-400 to-blue-500 text-white font-bold text-2xl rounded-full shadow-lg transform hover:scale-105 transition-transform duration-300"
      >
        CHƠI LẠI
      </button>
    </div>
  );
};

export default GameOverScreen;
