
import React from 'react';
import { PRIZE_AMOUNTS, TOTAL_QUESTIONS } from '../constants';

interface PrizeLadderProps {
  currentQuestion: number; // 1-15
}

const PrizeLadder: React.FC<PrizeLadderProps> = ({ currentQuestion }) => {
  const currentLevelIndex = TOTAL_QUESTIONS - currentQuestion;

  return (
    <div className="bg-indigo-900/50 border-2 border-cyan-400 p-4 rounded-lg h-full">
      <ul className="flex flex-col-reverse text-lg">
        {PRIZE_AMOUNTS.map((amount, index) => {
          const questionNum = TOTAL_QUESTIONS - index;
          const isCurrent = currentLevelIndex === index;
          const isMilestone = [1, 5, 10].includes(questionNum);
          
          let classes = "flex justify-between p-2 rounded transition-colors duration-300 ";
          if (isCurrent) {
            classes += "bg-yellow-500 text-black font-bold animate-pulse";
          } else if (isMilestone) {
            classes += "text-yellow-300 font-bold";
          } else {
            classes += "text-gray-300";
          }

          return (
            <li key={amount} className={classes}>
              <span className="text-cyan-400 mr-2">{questionNum}</span>
              <span>{amount} VNĐ</span>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default PrizeLadder;
