
import React from 'react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center text-center h-full">
        <div className="animate-spin rounded-full h-32 w-32 border-t-4 border-b-4 border-cyan-400 mb-6"></div>
        <h2 className="text-3xl text-yellow-300 font-bold">Đang tải bộ câu hỏi...</h2>
        <p className="text-lg text-gray-300 mt-2">Vui lòng chờ trong giây lát.</p>
    </div>
  );
};

export default LoadingScreen;
