
import React from 'react';

interface StartScreenProps {
  onStart: () => void;
  error: string | null;
}

const StartScreen: React.FC<StartScreenProps> = ({ onStart, error }) => {
  return (
    <div className="text-center flex flex-col items-center justify-center h-full">
      <img src="https://upload.wikimedia.org/wikipedia/vi/a/a2/Logo_Ai_la_trieu_phu_2020.png" alt="Ai là Triệu Phú Logo" className="w-64 h-64 mb-8"/>
      <h1 className="text-5xl font-bold mb-4 text-yellow-300 tracking-wider">AI LÀ TRIỆU PHÚ</h1>
      <h2 className="text-2xl text-cyan-300 mb-8">Chủ đề: Tính Đơn Điệu Của Hàm Số</h2>
      <button
        onClick={onStart}
        className="px-12 py-4 bg-gradient-to-b from-yellow-400 to-orange-500 text-black font-bold text-2xl rounded-full shadow-lg transform hover:scale-105 transition-transform duration-300"
      >
        BẮT ĐẦU
      </button>
      {error && <p className="text-red-500 mt-4">{error}</p>}
    </div>
  );
};

export default StartScreen;
