
import React from 'react';
import { PRIZE_AMOUNTS } from '../constants';

interface WinScreenProps {
  onPlayAgain: () => void;
}

const WinScreen: React.FC<WinScreenProps> = ({ onPlayAgain }) => {
  const topPrize = PRIZE_AMOUNTS[0];

  return (
    <div className="text-center flex flex-col items-center justify-center h-full">
      <h1 className="text-5xl font-bold mb-4 text-yellow-300">CHÚC MỪNG!</h1>
      <p className="text-3xl text-cyan-300 mb-8">
        Bạn đã trở thành TRIỆU PHÚ với giải thưởng <span className="font-bold text-yellow-300">{topPrize} VNĐ</span>
      </p>
      <button
        onClick={onPlayAgain}
        className="px-12 py-4 bg-gradient-to-b from-yellow-400 to-orange-500 text-black font-bold text-2xl rounded-full shadow-lg transform hover:scale-105 transition-transform duration-300"
      >
        CHƠI LẠI
      </button>
    </div>
  );
};

export default WinScreen;
