
import React, { useState, useEffect, useRef } from 'react';

interface TimerProps {
  duration: number;
  onTimeUp: () => void;
  isPaused: boolean;
  playSound: (sound: 'timer') => void;
  stopSound: () => void;
}

const Timer: React.FC<TimerProps> = ({ duration, onTimeUp, isPaused, playSound, stopSound }) => {
  const [timeLeft, setTimeLeft] = useState(duration);
  const intervalRef = useRef<number | null>(null);
  
  const hasPlayedTimerSound = useRef(false);

  useEffect(() => {
    if (isPaused) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      stopSound();
      hasPlayedTimerSound.current = false;
      return;
    }

    intervalRef.current = window.setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          if (intervalRef.current) clearInterval(intervalRef.current);
          onTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isPaused, onTimeUp]);
  
  useEffect(() => {
    if (!isPaused && timeLeft <= 10 && !hasPlayedTimerSound.current) {
      stopSound();
      playSound('timer');
      hasPlayedTimerSound.current = true;
    }
  }, [timeLeft, isPaused, playSound, stopSound]);

  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (timeLeft / duration) * circumference;

  const color = timeLeft <= 10 ? 'text-red-500' : 'text-yellow-300';
  const strokeColor = timeLeft <= 10 ? 'stroke-red-500' : 'stroke-cyan-400';

  return (
    <div className="relative w-32 h-32 flex items-center justify-center">
      <svg className="absolute top-0 left-0 w-full h-full transform -rotate-90">
        <circle
          cx="50%"
          cy="50%"
          r={radius}
          strokeWidth="8"
          className="stroke-gray-700"
          fill="transparent"
        />
        <circle
          cx="50%"
          cy="50%"
          r={radius}
          strokeWidth="8"
          fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          className={`transition-all duration-1000 ${strokeColor}`}
          strokeLinecap="round"
        />
      </svg>
      <span className={`text-5xl font-bold ${color}`}>{timeLeft}</span>
    </div>
  );
};

export default Timer;
