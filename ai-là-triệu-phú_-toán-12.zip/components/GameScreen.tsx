
import React, { useState, useEffect, useCallback } from 'react';
import { Question } from '../types';
import { TIME_PER_QUESTION } from '../constants';
import PrizeLadder from './PrizeLadder';
import Timer from './Timer';

interface GameScreenProps {
  question: Question;
  questionNumber: number;
  onAnswer: (isCorrect: boolean) => void;
  onTimeUp: () => void;
  playSound: (sound: 'timer' | 'play') => void;
  stopSound: () => void;
}

const AnswerButton: React.FC<{
    prefix: string;
    text: string;
    onClick: () => void;
    state: 'default' | 'selected' | 'correct' | 'incorrect';
    disabled: boolean;
}> = ({ prefix, text, onClick, state, disabled }) => {
    const baseClasses = "w-full text-left p-3 pl-12 rounded-full border-2 transition-all duration-300 transform focus:outline-none disabled:cursor-not-allowed";
    const stateClasses = {
        default: "bg-indigo-900/50 border-cyan-400 hover:bg-indigo-700/70 hover:scale-105 text-white",
        selected: "bg-yellow-500 border-yellow-300 scale-105 text-black font-bold animate-pulse",
        correct: "bg-green-500 border-green-300 scale-105 text-white font-bold",
        incorrect: "bg-red-500 border-red-300 scale-105 text-white font-bold",
    };

    return (
        <button onClick={onClick} disabled={disabled} className={`${baseClasses} ${stateClasses[state]}`}>
            <span className="font-bold text-yellow-300 mr-2">{prefix}:</span> {text}
        </button>
    );
};

const GameScreen: React.FC<GameScreenProps> = ({ question, questionNumber, onAnswer, onTimeUp, playSound, stopSound }) => {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);

  useEffect(() => {
    setSelectedAnswer(null);
    setIsAnswered(false);
  }, [question]);

  const handleAnswerClick = (index: number) => {
    if (isAnswered) return;
    setIsAnswered(true);
    setSelectedAnswer(index);
    stopSound();

    setTimeout(() => {
      onAnswer(index === question.correctAnswerIndex);
    }, 2000);
  };

  const getButtonState = (index: number): 'default' | 'selected' | 'correct' | 'incorrect' => {
      if (!isAnswered) {
          return 'default';
      }
      if (index === question.correctAnswerIndex) {
          return 'correct';
      }
      if (index === selectedAnswer && index !== question.correctAnswerIndex) {
          return 'incorrect';
      }
      return 'default';
  };


  return (
    <div className="flex flex-col lg:flex-row gap-8 items-center justify-center">
      <div className="w-full lg:w-3/4 flex flex-col items-center justify-between min-h-[60vh]">
        <div className="w-full flex justify-center mb-6">
            <Timer
                key={questionNumber}
                duration={TIME_PER_QUESTION}
                onTimeUp={onTimeUp}
                isPaused={isAnswered}
                playSound={playSound}
                stopSound={stopSound}
            />
        </div>
        
        <div className="w-full bg-indigo-900/50 border-2 border-cyan-400 rounded-lg p-6 mb-8 text-center text-xl md:text-2xl">
          {question.question}
        </div>

        <div className="w-full grid grid-cols-1 md:grid-cols-2 gap-4">
          {question.answers.map((answer, index) => (
            <AnswerButton 
              key={index}
              prefix={String.fromCharCode(65 + index)}
              text={answer}
              onClick={() => handleAnswerClick(index)}
              disabled={isAnswered}
              state={getButtonState(index)}
            />
          ))}
        </div>
      </div>
      <div className="w-full lg:w-1/4">
        <PrizeLadder currentQuestion={questionNumber} />
      </div>
    </div>
  );
};

export default GameScreen;
