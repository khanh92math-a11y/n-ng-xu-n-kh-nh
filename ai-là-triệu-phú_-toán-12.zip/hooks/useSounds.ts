
import { useMemo, useCallback } from 'react';

const sounds = {
  start: 'https://cdn.pixabay.com/audio/2022/08/23/audio_82c6ce5a7d.mp3',
  play: 'https://cdn.pixabay.com/audio/2022/10/17/audio_c384a86976.mp3',
  correct: 'https://cdn.pixabay.com/audio/2022/03/10/audio_c87998805f.mp3',
  wrong: 'https://cdn.pixabay.com/audio/2023/04/18/audio_3490072b23.mp3',
  timer: 'https://cdn.pixabay.com/audio/2021/10/08/audio_75347208f8.mp3',
  win: 'https://cdn.pixabay.com/audio/2022/11/17/audio_88f2cfce37.mp3'
};

type SoundName = keyof typeof sounds;

export const useSounds = () => {
  const audioObjects = useMemo(() => {
    const audios: { [key in SoundName]?: HTMLAudioElement } = {};
    for (const key in sounds) {
      audios[key as SoundName] = new Audio(sounds[key as SoundName]);
    }
    if (audios.play) audios.play.loop = true;
    if (audios.timer) audios.timer.loop = true;
    return audios;
  }, []);

  const playSound = useCallback((name: SoundName) => {
    Object.values(audioObjects).forEach(audio => audio?.pause());
    const audio = audioObjects[name];
    if (audio) {
      audio.currentTime = 0;
      audio.play().catch(e => console.error(`Error playing sound ${name}:`, e));
    }
  }, [audioObjects]);

  const stopAllSounds = useCallback(() => {
    Object.values(audioObjects).forEach(audio => {
        if (audio) {
            audio.pause();
            audio.currentTime = 0;
        }
    });
  }, [audioObjects]);
  
  const stopSound = useCallback((name: SoundName) => {
    const audio = audioObjects[name];
    if (audio) {
        audio.pause();
        audio.currentTime = 0;
    }
  }, [audioObjects]);

  return { playSound, stopAllSounds, stopSound };
};
